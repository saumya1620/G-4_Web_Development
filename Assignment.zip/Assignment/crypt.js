const crypto = require ('crypto');
//console.log(crypto.getHashes());
// const hash = crypto.createHash('sha256')
// .update('saumya')
// .digest('hex');
// console.log('SHA-256 Hash:',hash)

// const hmac=crypto.createHmac('sha256','secret-key')
// .update('message')
// .digest('hex');
// console.log('HMAC:',hmac);

// const token = crypto.randomBytes(16).toString('hex');
// console.log('Token',token)

// crypto.randomInt(1,7,(err,n)=>
// {
//     if(err) throw err;
//     console.log("random int",n);
// })

// crypto.generateKeyPair('rsa',{
//     modulusLength:2048,
// }, (err,publicKey,privateKey)=>
// {
//     console.log('Public key',publicKey.export({type:'pkcs1',format:'pem'}));
//     console.log('Private key',privateKey.export({type:'pkcs1',format:'pem'}));
// });

