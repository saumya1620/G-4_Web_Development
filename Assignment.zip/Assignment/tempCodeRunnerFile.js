crypto.generateKeyPair('rsa',{
//     modulusLength:2048,
// }, (err,publicKey,privateKey)=>
// {
//     console.log('Public key',publicKey.export({type:'pkcs1',format:'pem'}));
//     console.log('Private key',privateKey.export({type:'pkcs1',format:'pem'}));
// });